package com.xaf.autofollow

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    private var tick by mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) { Screen(tick) }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        tick++
    }
}

private fun a11yOn(ctx: Context): Boolean {
    val s = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
    return s.contains("${ctx.packageName}/${FollowService::class.java.name}")
}

@Composable
private fun Section(title: String, content: @Composable () -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(title, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
            content()
        }
    }
}

@Composable
private fun PermRow(label: String, ok: Boolean, btn: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
        Column(Modifier.weight(1f)) {
            Text(label)
            Text(
                if (ok) "● Enabled" else "● Not enabled",
                color = if (ok) Color(0xFF16A34A) else Color(0xFFDC2626), fontSize = 12.sp
            )
        }
        OutlinedButton(onClick = onClick) { Text(if (ok) "Open" else btn) }
    }
}

@Composable
private fun Num(label: String, value: String, mod: Modifier = Modifier.fillMaxWidth(), onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = { onChange(it.filter { c -> c.isDigit() }.take(6)) },
        label = { Text(label) },
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        modifier = mod
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun Screen(tick: Int) {
    val ctx = LocalContext.current
    val a11y = remember(tick) { a11yOn(ctx) }
    val overlay = remember(tick) { Settings.canDrawOverlays(ctx) }

    var urls by remember { mutableStateOf(Prefs.get(ctx, "urls", "")) }
    var per by remember { mutableStateOf(Prefs.get(ctx, "per", "50")) }
    var dMin by remember { mutableStateOf(Prefs.get(ctx, "dmin", "3")) }
    var dMax by remember { mutableStateOf(Prefs.get(ctx, "dmax", "8")) }
    var waitAcc by remember { mutableStateOf(Prefs.get(ctx, "wacc", "30")) }
    var waitAll by remember { mutableStateOf(Prefs.get(ctx, "wall", "10")) }
    var allMinutes by remember { mutableStateOf(Prefs.get(ctx, "wallunit", "min") == "min") }

    fun toast(m: String) = Toast.makeText(ctx, m, Toast.LENGTH_LONG).show()

    fun start() {
        val list = urls.lines().map { it.trim() }.filter { it.isNotEmpty() }
        val re = Regex("^https?://(www\\.)?(x|twitter)\\.com/i/communities/\\d+.*$", RegexOption.IGNORE_CASE)
        val p = per.toIntOrNull() ?: 0
        val mn = dMin.toIntOrNull() ?: -1
        val mx = dMax.toIntOrNull() ?: -1
        val wa = waitAcc.toIntOrNull() ?: -1
        val wl = waitAll.toIntOrNull() ?: -1
        when {
            !a11y -> return toast("Enable the Accessibility Service first")
            !overlay -> return toast("Allow Display Over Other Apps first")
            list.isEmpty() || list.any { !re.matches(it) } -> return toast("Enter valid X Community URLs (https://x.com/i/communities/...)")
            p < 1 -> return toast("Follows per account must be at least 1")
            mn < 0 || mx < mn -> return toast("Delay: max must be >= min")
            wa < 0 || wl < 0 -> return toast("Enter valid wait timers")
        }
        val svc = FollowService.instance
        if (svc == null) return toast("Accessibility service is not connected. Toggle it off and on again.")
        Prefs.put(
            ctx, mapOf(
                "urls" to urls, "per" to per, "dmin" to dMin, "dmax" to dMax,
                "wacc" to waitAcc, "wall" to waitAll, "wallunit" to if (allMinutes) "min" else "sec"
            )
        )
        svc.start(Config(list, p, mn, mx, wa, if (allMinutes) wl * 60 else wl))
    }

    Column(
        Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("X Auto Follow", fontSize = 26.sp, fontWeight = FontWeight.Bold)

        Section("Permissions") {
            PermRow("Accessibility Service", a11y, "Enable") {
                ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
            PermRow("Display Over Other Apps", overlay, "Enable") {
                ctx.startActivity(
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}"))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            }
        }

        Section("Community Target") {
            OutlinedTextField(
                value = urls, onValueChange = { urls = it },
                label = { Text("X Community URLs (one per line)") },
                placeholder = { Text("https://x.com/i/communities/123456789") },
                minLines = 2, modifier = Modifier.fillMaxWidth()
            )
        }

        Section("Follow & Delay Settings") {
            Num("Follows per account", per) { per = it }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Num("Min delay (s)", dMin, Modifier.weight(1f)) { dMin = it }
                Num("Max delay (s)", dMax, Modifier.weight(1f)) { dMax = it }
            }
        }

        Section("Rest / Wait Timers") {
            Num("Wait after 1 account (seconds)", waitAcc) { waitAcc = it }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Num("Wait after all accounts", waitAll, Modifier.weight(1f)) { waitAll = it }
                FilterChip(selected = !allMinutes, onClick = { allMinutes = false }, label = { Text("sec") })
                FilterChip(selected = allMinutes, onClick = { allMinutes = true }, label = { Text("min") })
            }
        }

        Button(onClick = { start() }, modifier = Modifier.fillMaxWidth().height(56.dp)) {
            Text("START", fontSize = 18.sp, fontWeight = FontWeight.Bold)
        }
    }
}
