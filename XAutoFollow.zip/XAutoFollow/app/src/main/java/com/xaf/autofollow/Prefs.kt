package com.xaf.autofollow

import android.content.Context

data class Config(
    val urls: List<String>,
    val perAccount: Int,
    val minDelay: Int,
    val maxDelay: Int,
    val waitAccount: Int,
    val waitAllSec: Int
)

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("xaf", Context.MODE_PRIVATE)
    fun get(c: Context, k: String, d: String): String = sp(c).getString(k, d) ?: d
    fun put(c: Context, m: Map<String, String>) {
        val e = sp(c).edit()
        m.forEach { (k, v) -> e.putString(k, v) }
        e.apply()
    }
}
