package com.xaf.autofollow

import android.os.SystemClock
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay
import kotlin.random.Random

class Engine(
    private val svc: FollowService,
    private val cfg: Config,
    private val ui: (String) -> Unit
) {
    private val rd = Reader(svc)
    private val visited = HashSet<String>()
    private var dual = false
    private var done = 0

    /** Infinite loop: First X -> Dual/Clone X -> First X ... until the coroutine is cancelled (STOP). */
    suspend fun run() {
        while (true) {
            try {
                val list = Device.detect(svc)
                if (list.isEmpty()) {
                    ui("X app not found"); delay(5000); continue
                }
                for ((i, x) in list.withIndex()) {
                    dual = i > 0
                    visited.clear()
                    ui(if (i == 0) "Opening X..." else "Switching to Dual X...")
                    Device.launch(svc, x)
                    delay(2500)
                    do {
                        followQuota(x)
                        countdown(cfg.waitAccount)
                        ui("Switching account...")
                    } while (switchAccount(x))
                }
                countdown(cfg.waitAllSec)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                ui("Recovering...")
                delay(3000)
            }
        }
    }

    // ---------- helpers ----------
    private suspend fun rnd() {
        val lo = cfg.minDelay * 1000L
        val hi = maxOf(lo, cfg.maxDelay * 1000L)
        delay(Random.nextLong(lo, hi + 1))
    }

    private suspend fun countdown(sec: Int) {
        var s = sec
        while (s > 0) {
            ui(if (s >= 60) "Waiting ${s / 60}m ${s % 60}s..." else "Waiting ${s}s...")
            delay(1000)
            s--
        }
    }

    /** Handles the "Open with" chooser and transient popups. Returns true if it acted. */
    private fun housekeeping(): Boolean {
        if (rd.chooserShown()) return rd.pickChooser(dual)
        return rd.dismissPopups()
    }

    private suspend fun waitFor(ms: Long, cond: () -> Boolean): Boolean {
        val end = SystemClock.elapsedRealtime() + ms
        while (SystemClock.elapsedRealtime() < end) {
            if (cond()) return true
            if (housekeeping()) delay(800)
            delay(400)
        }
        return cond()
    }

    private suspend fun openCommunity(x: XInstance, url: String): Boolean {
        Device.launch(svc, x)
        delay(1200)
        Device.openUrl(svc, x, url)
        return waitFor(15000) { rd.handles().isNotEmpty() && rd.relation() == Rel.NONE }
    }

    private suspend fun backToFeed(x: XInstance, url: String) {
        repeat(4) {
            rd.back()
            delay(900)
            housekeeping()
            if (rd.relation() == Rel.NONE && rd.handles().isNotEmpty()) return
        }
        openCommunity(x, url)
    }

    // ---------- follow routine ----------
    private suspend fun followQuota(x: XInstance) {
        done = 0
        ui("Following 0/${cfg.perAccount}")
        val processed = HashSet<String>()
        var u = 0
        var exhausted = 0
        var stall = 0
        openCommunity(x, cfg.urls[0])
        while (done < cfg.perAccount) {
            housekeeping()
            val cand = rd.handles().firstOrNull { it.first !in processed }
            if (cand == null) {
                stall++
                if (stall >= 8) {
                    exhausted++
                    if (exhausted >= cfg.urls.size) return
                    u = (u + 1) % cfg.urls.size
                    openCommunity(x, cfg.urls[u])
                    stall = 0
                    continue
                }
                rd.swipeUp()
                rnd()
                continue
            }
            stall = 0
            processed.add(cand.first)
            // FIX 1: tap the @handle node's own bounds center so X opens the author's profile
            // (clickNode() could climb to the tweet container and open the tweet details).
            if (!rd.tapNode(cand.second)) continue
            delay(1200)
            var rel = Rel.NONE
            waitFor(6000) { rel = rd.relation(); rel != Rel.NONE }
            if (rel == Rel.FOLLOW && rd.clickFollow()) {
                delay(1000)
                if (waitFor(3000) { rd.relation() == Rel.DONE }) {
                    done++
                    exhausted = 0
                    ui("Following $done/${cfg.perAccount}")
                }
            }
            backToFeed(x, cfg.urls[u])
            rnd()
        }
    }

    // ---------- account rotation ----------
    private suspend fun goHome(x: XInstance): Boolean {
        repeat(8) {
            val p = rd.pkg()
            if (p.isNotEmpty() && !p.contains("twitter") && !p.startsWith("android") &&
                !p.contains("resolver") && p != x.pkg
            ) {
                Device.launch(svc, x); delay(2500)
            }
            housekeeping()
            if (rd.findDesc("navigation drawer") != null) return true
            val tab = rd.nodes().firstOrNull {
                it.isVisibleToUser && it.isClickable && it.dsc().startsWith("Home", true)
            }
            if (tab != null) rd.clickNode(tab) else rd.back()
            delay(900)
        }
        return false
    }

    private suspend fun discoverAccounts(): Map<String, Boolean> {
        val found = LinkedHashMap<String, Boolean>()
        repeat(6) { if (rd.scrollSheet(false)) delay(300) }
        var idle = 0
        while (idle < 2 && found.size < 300) {
            val before = found.size
            rd.sheetRows().forEach { found[it.first] = (found[it.first] == true) || it.second }
            idle = if (found.size == before) idle + 1 else 0
            if (!rd.scrollSheet(true)) break
            delay(500)
        }
        return found
    }

    private suspend fun clickHandleInSheet(h: String): Boolean {
        repeat(6) { if (rd.scrollSheet(false)) delay(350) }
        repeat(12) {
            val row = rd.sheetRows().firstOrNull { it.first == h }
            if (row != null) return rd.clickNode(row.third)
            if (!rd.scrollSheet(true)) return false
            delay(450)
        }
        return false
    }

    /** Returns true if it switched to a new unvisited account; false when every account was visited. */
    private suspend fun switchAccount(x: XInstance): Boolean {
        repeat(3) {
            if (!goHome(x)) return@repeat
            val avatar = rd.findDesc("navigation drawer") ?: return@repeat
            // Remember what the Home feed shows so the drawer reader can ignore feed authors.
            val feedBefore = rd.handles().map { it.first }.toSet()
            rd.clickNode(avatar)
            delay(1300)
            val more = rd.accountsIcon()
            if (more == null) { rd.back(); delay(600); return@repeat }
            // FIX 2: read the signed-in @handle from the open drawer header BEFORE tapping the
            // accounts icon, and mark it visited right away so it is never re-selected.
            rd.drawerHandle(more, feedBefore)?.let { visited.add(it) }
            rd.clickNode(more)
            if (!waitFor(6000) { rd.sheetRows().isNotEmpty() }) { rd.back(); delay(600); return@repeat }
            val acc = discoverAccounts()
            // Secondary source: the sheet's selected/checked row (kept as a safety net).
            acc.filter { it.value }.keys.forEach { visited.add(it) }
            val next = acc.keys.firstOrNull { it !in visited }
            if (next == null) {
                rd.back(); delay(500); rd.back(); delay(500)
                return false
            }
            if (!clickHandleInSheet(next)) { rd.back(); delay(600); return@repeat }
            visited.add(next)
            ui("Switching account...")
            delay(2500)
            waitFor(25000) { rd.findDesc("navigation drawer") != null }
            delay(2500)
            return true
        }
        return false
    }
}
