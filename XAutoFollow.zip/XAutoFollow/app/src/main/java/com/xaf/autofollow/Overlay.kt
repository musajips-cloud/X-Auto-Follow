package com.xaf.autofollow

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class Overlay(private val ctx: Context, private val onStop: () -> Unit) {
    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val h = Handler(Looper.getMainLooper())
    private var root: LinearLayout? = null
    private var label: TextView? = null
    private var dot: View? = null
    private val lp = WindowManager.LayoutParams(
        WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
        PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.TOP or Gravity.START; x = 40; y = 180 }

    private fun dp(v: Int) = (v * ctx.resources.displayMetrics.density).toInt()

    private fun circle(color: Int) = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(color) }

    fun show() = h.post {
        if (root != null) return@post
        val pill = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(6), dp(8), dp(6))
            background = GradientDrawable().apply { cornerRadius = dp(28).toFloat(); setColor(Color.parseColor("#E6141414")) }
        }
        val d = View(ctx).apply { background = circle(Color.parseColor("#22C55E")) }
        pill.addView(d, LinearLayout.LayoutParams(dp(10), dp(10)).apply { rightMargin = dp(10) })
        val t = TextView(ctx).apply { setTextColor(Color.WHITE); textSize = 13f; text = "Starting..." }
        pill.addView(t)
        val b = Button(ctx).apply {
            text = "STOP"; textSize = 12f; setTextColor(Color.BLACK); isAllCaps = true
            background = GradientDrawable().apply { cornerRadius = dp(20).toFloat(); setColor(Color.parseColor("#FACC15")) }
            minHeight = 0; minimumHeight = 0; minWidth = 0; minimumWidth = 0
            setPadding(dp(14), dp(6), dp(14), dp(6))
            setOnClickListener { onStop() }
        }
        pill.addView(b, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, dp(34)).apply { leftMargin = dp(12) })

        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0
        pill.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = ox + (e.rawX - sx).toInt()
                    lp.y = oy + (e.rawY - sy).toInt()
                    try { wm.updateViewLayout(pill, lp) } catch (ex: Exception) { }
                }
            }
            true
        }
        try {
            wm.addView(pill, lp)
            root = pill; label = t; dot = d
        } catch (ex: Exception) { }
    }

    fun set(text: String) = h.post {
        label?.text = text
        val warn = text.startsWith("Waiting") || text.startsWith("Switching") || text.startsWith("Recovering")
        dot?.background = circle(Color.parseColor(if (warn) "#F59E0B" else "#22C55E"))
    }

    fun hide() = h.post {
        root?.let { try { wm.removeView(it) } catch (ex: Exception) { } }
        root = null; label = null; dot = null
    }
}
