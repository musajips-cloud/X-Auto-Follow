package com.xaf.autofollow

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.LauncherApps
import android.net.Uri
import android.os.Process
import android.os.UserHandle
import android.os.UserManager

data class XInstance(
    val pkg: String,
    val user: UserHandle,
    val component: ComponentName,
    val label: String,
    val isPrimary: Boolean
)

object Device {
    const val X = "com.twitter.android"

    /** Returns [First X, then every Dual/Twin/Clone X]. */
    fun detect(ctx: Context): List<XInstance> {
        val la = ctx.getSystemService(Context.LAUNCHER_APPS_SERVICE) as LauncherApps
        val um = ctx.getSystemService(Context.USER_SERVICE) as UserManager
        val me = Process.myUserHandle()
        val primary = ArrayList<XInstance>()
        val others = ArrayList<XInstance>()
        try {
            for (u in um.userProfiles) {
                for (info in la.getActivityList(X, u)) {
                    val inst = XInstance(X, u, info.componentName, info.label?.toString() ?: "X", u == me)
                    if (u == me) primary.add(inst) else others.add(inst)
                }
            }
        } catch (e: Exception) { }
        // Cloned package variants living in the main user (e.g. com.twitter.android.clone)
        try {
            val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            for (ri in ctx.packageManager.queryIntentActivities(i, 0)) {
                val p = ri.activityInfo.packageName
                if (p != X && p != ctx.packageName && (p.startsWith("com.twitter.android") || p.contains(".twitter."))) {
                    others.add(
                        XInstance(
                            p, me, ComponentName(p, ri.activityInfo.name),
                            ri.loadLabel(ctx.packageManager).toString(), false
                        )
                    )
                }
            }
        } catch (e: Exception) { }
        val result = ArrayList<XInstance>()
        result.addAll(primary.take(1))
        result.addAll(others.distinctBy { it.pkg + "/" + it.user.hashCode() })
        return result
    }

    fun launch(ctx: Context, x: XInstance) {
        try {
            val la = ctx.getSystemService(Context.LAUNCHER_APPS_SERVICE) as LauncherApps
            la.startMainActivity(x.component, x.user, null, null)
        } catch (e: Exception) {
            val i = ctx.packageManager.getLaunchIntentForPackage(x.pkg) ?: return
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            try { ctx.startActivity(i) } catch (ex: Exception) { }
        }
    }

    /**
     * Opens the community link. The target X was already brought to the foreground via
     * LauncherApps. For secondary instances no package is forced, so Android's "Open with"
     * chooser may appear and is handled by Reader.pickChooser().
     */
    fun openUrl(ctx: Context, x: XInstance, url: String) {
        val i = Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (x.isPrimary || x.pkg != X) i.setPackage(x.pkg)
        try {
            ctx.startActivity(i)
        } catch (e: Exception) {
            try {
                i.setPackage(null)
                ctx.startActivity(i)
            } catch (ex: Exception) { }
        }
    }
}
