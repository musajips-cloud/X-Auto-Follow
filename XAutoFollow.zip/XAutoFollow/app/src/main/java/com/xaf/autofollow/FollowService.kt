package com.xaf.autofollow

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class FollowService : AccessibilityService() {
    companion object {
        @Volatile var instance: FollowService? = null
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var job: Job? = null
    private var overlay: Overlay? = null

    override fun onServiceConnected() { instance = this }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    fun isRunning() = job?.isActive == true

    fun start(cfg: Config) {
        if (isRunning()) return
        val ov = Overlay(this) { stop() }
        overlay = ov
        ov.show()
        job = scope.launch {
            try {
                Engine(this@FollowService, cfg) { ov.set(it) }.run()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                ov.set("Error: ${e.message}")
            }
        }
    }

    fun stop() {
        job?.cancel()
        job = null
        overlay?.hide()
        overlay = null
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        stop(); instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        stop(); instance = null
        super.onDestroy()
    }
}
