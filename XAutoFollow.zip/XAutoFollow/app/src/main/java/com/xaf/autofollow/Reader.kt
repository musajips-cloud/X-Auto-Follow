package com.xaf.autofollow

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.Rect
import android.view.accessibility.AccessibilityNodeInfo
import kotlin.math.abs

val HANDLE_RE = Regex("@[A-Za-z0-9_]{1,15}")
private val ACTIVE_RE = Regex("selected|current|checkmark|checked", RegexOption.IGNORE_CASE)

fun AccessibilityNodeInfo.all(): List<AccessibilityNodeInfo> {
    val out = ArrayList<AccessibilityNodeInfo>()
    fun rec(n: AccessibilityNodeInfo, d: Int) {
        out.add(n)
        if (d > 40) return
        for (i in 0 until n.childCount) {
            val c = n.getChild(i) ?: continue
            rec(c, d + 1)
        }
    }
    rec(this, 0)
    return out
}

fun AccessibilityNodeInfo.txt(): String = text?.toString()?.trim().orEmpty()
fun AccessibilityNodeInfo.dsc(): String = contentDescription?.toString()?.trim().orEmpty()

enum class Rel { NONE, FOLLOW, DONE }

class Reader(private val svc: AccessibilityService) {
    private val dm = svc.resources.displayMetrics

    fun nodes(): List<AccessibilityNodeInfo> = try {
        svc.rootInActiveWindow?.all() ?: emptyList()
    } catch (e: Exception) { emptyList() }

    fun pkg(): String = try { svc.rootInActiveWindow?.packageName?.toString().orEmpty() } catch (e: Exception) { "" }

    fun back() = svc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK)

    // ---------- gestures & clicks ----------
    fun tapAt(x: Float, y: Float): Boolean {
        val p = Path().apply { moveTo(x, y) }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(p, 0, 60)).build()
        return svc.dispatchGesture(g, null, null)
    }

    /**
     * FIX 1: taps the exact center of the node's on-screen bounds. It never walks up to a
     * clickable parent, so a feed @handle opens the author's profile and not the tweet details.
     */
    fun tapNode(n: AccessibilityNodeInfo): Boolean {
        val r = Rect()
        n.getBoundsInScreen(r)
        if (r.isEmpty) return false
        val x = r.exactCenterX().coerceIn(1f, dm.widthPixels - 1f)
        val y = r.exactCenterY().coerceIn(1f, dm.heightPixels - 1f)
        return tapAt(x, y)
    }

    fun swipeUp() {
        val x = dm.widthPixels / 2f
        val p = Path().apply {
            moveTo(x, dm.heightPixels * 0.75f)
            lineTo(x, dm.heightPixels * 0.35f)
        }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(p, 0, 550)).build()
        svc.dispatchGesture(g, null, null)
    }

    /** Clicks the node or its nearest clickable ancestor (use for buttons, not for feed handles). */
    fun clickNode(n: AccessibilityNodeInfo): Boolean {
        var c: AccessibilityNodeInfo? = n
        var i = 0
        while (c != null && i < 6) {
            if (c.isClickable && c.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            c = c.parent
            i++
        }
        return tapNode(n)
    }

    // ---------- finders ----------
    fun findDesc(sub: String): AccessibilityNodeInfo? =
        nodes().firstOrNull { it.isVisibleToUser && it.dsc().contains(sub, true) }

    fun clickTextAny(vararg labels: String): Boolean {
        val n = nodes().firstOrNull { nd ->
            nd.isVisibleToUser && nd.isEnabled &&
                labels.any { l -> nd.txt().equals(l, true) || nd.dsc().equals(l, true) }
        } ?: return false
        return clickNode(n)
    }

    fun dismissPopups(): Boolean =
        clickTextAny("Not now", "Skip for now", "Maybe later", "Got it", "No thanks", "Dismiss", "Later")

    fun accountsIcon(): AccessibilityNodeInfo? {
        val ns = nodes().filter { it.isVisibleToUser }
        return ns.firstOrNull { it.dsc().contains("account", true) && !it.dsc().contains("navigation", true) }
            ?: ns.firstOrNull { it.dsc().equals("More", true) || it.dsc().equals("More options", true) }
    }

    // ---------- handles ----------
    fun handleIn(n: AccessibilityNodeInfo): String? {
        val t = n.txt()
        if (t.isEmpty() || t.length > 60) return null
        val m = HANDLE_RE.find(t) ?: return null
        return if (t == m.value || t.contains("·")) m.value.lowercase() else null
    }

    /** Visible author handles on a feed screen, top to bottom. */
    fun handles(): List<Pair<String, AccessibilityNodeInfo>> {
        val r = Rect()
        val list = ArrayList<Triple<Int, String, AccessibilityNodeInfo>>()
        for (n in nodes()) {
            if (!n.isVisibleToUser) continue
            val h = handleIn(n) ?: continue
            n.getBoundsInScreen(r)
            if (r.top < dm.heightPixels * 0.12 || r.bottom > dm.heightPixels * 0.95) continue
            list.add(Triple(r.top, h, n))
        }
        return list.sortedBy { it.first }.distinctBy { it.second }.map { it.second to it.third }
    }

    // ---------- navigation drawer header ----------
    /** First line of [t] that is exactly "@handle" (lower-cased), or null. */
    private fun exactHandle(t: String): String? {
        for (line in t.lines()) {
            val s = line.trim()
            if (HANDLE_RE.matches(s)) return s.lowercase()
        }
        return null
    }

    /**
     * FIX 2: reads the signed-in account's @handle from the OPEN navigation drawer header.
     * [anchor] is the drawer's accounts/more icon. [feedBefore] are the handles that were on the
     * Home feed before the drawer opened; the fallback ignores them so feed authors are never
     * mistaken for the active account.
     */
    fun drawerHandle(anchor: AccessibilityNodeInfo?, feedBefore: Set<String>): String? {
        // 1) Climb from the accounts icon to the nearest drawer-sized container holding an @handle.
        if (anchor != null) {
            val ar = Rect()
            anchor.getBoundsInScreen(ar)
            var cur: AccessibilityNodeInfo? = anchor.parent
            var hops = 0
            while (cur != null && hops < 8) {
                val cr = Rect()
                cur.getBoundsInScreen(cr)
                if (cr.width() >= dm.widthPixels * 0.98) break // full-screen container would include the feed
                var near: String? = null
                var nearDist = Int.MAX_VALUE
                val hr = Rect()
                for (n in cur.all()) {
                    if (!n.isVisibleToUser) continue
                    val h = exactHandle(n.txt()) ?: continue
                    n.getBoundsInScreen(hr)
                    val dist = abs(hr.centerY() - ar.centerY())
                    if (dist < nearDist) { nearDist = dist; near = h }
                }
                if (near != null) return near
                cur = cur.parent
                hops++
            }
        }
        // 2) Fallback: topmost exact @handle in the left part of the screen that was not on the feed.
        var top: String? = null
        var topY = Int.MAX_VALUE
        val r = Rect()
        for (n in nodes()) {
            if (!n.isVisibleToUser) continue
            val h = exactHandle(n.txt()) ?: continue
            if (h in feedBefore) continue
            n.getBoundsInScreen(r)
            if (r.left > dm.widthPixels * 0.6) continue
            if (r.top < topY) { topY = r.top; top = h }
        }
        return top
    }

    // ---------- profile relation ----------
    fun relation(): Rel {
        var follow = false
        for (n in nodes()) {
            if (!n.isVisibleToUser) continue
            val t = n.txt().lowercase()
            val d = n.dsc().lowercase()
            if (t == "following" || t == "pending" || t == "requested" || t == "unfollow" ||
                (n.isClickable && (d.startsWith("following") || d.startsWith("pending")))
            ) return Rel.DONE
            if (t == "follow" || t == "follow back" || d.startsWith("follow @")) follow = true
        }
        return if (follow) Rel.FOLLOW else Rel.NONE
    }

    fun clickFollow(): Boolean {
        val n = nodes().firstOrNull {
            it.isVisibleToUser && (it.txt().equals("follow", true) || it.txt().equals("follow back", true) ||
                it.dsc().startsWith("follow @", true))
        } ?: return false
        return clickNode(n)
    }

    // ---------- accounts sheet ----------
    private fun countHandles(n: AccessibilityNodeInfo) = n.all().count { handleIn(it) != null }

    private fun rowOf(n: AccessibilityNodeInfo): AccessibilityNodeInfo {
        var best = n
        var cur = n.parent
        var i = 0
        while (cur != null && i < 5) {
            if (countHandles(cur) > 1) break
            best = cur
            cur = cur.parent
            i++
        }
        return best
    }

    /** (handle, isActive, node) for each account row currently visible in the Accounts sheet. */
    fun sheetRows(): List<Triple<String, Boolean, AccessibilityNodeInfo>> {
        val out = LinkedHashMap<String, Triple<String, Boolean, AccessibilityNodeInfo>>()
        for (n in nodes()) {
            if (!n.isVisibleToUser) continue
            val h = handleIn(n) ?: continue
            val row = rowOf(n)
            val active = row.all().any {
                it.isChecked || it.isSelected || ACTIVE_RE.containsMatchIn(it.dsc()) || ACTIVE_RE.containsMatchIn(it.txt())
            }
            val old = out[h]
            out[h] = Triple(h, active || (old?.second == true), n)
        }
        return out.values.toList()
    }

    fun scrollSheet(forward: Boolean): Boolean {
        val sc = nodes().firstOrNull { s -> s.isScrollable && s.all().any { handleIn(it) != null } } ?: return false
        return sc.performAction(
            if (forward) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
        )
    }

    // ---------- "Open with" chooser ----------
    fun chooserShown(): Boolean = nodes().any {
        val t = it.txt()
        t.equals("Open with", true) || t.startsWith("Open with ", true) ||
            t.equals("Choose an app", true) || it.viewIdResourceName == "android:id/resolver_list"
    }

    /** Taps the first X option (Phase 1) or the second/badged X option (Phase 2). */
    fun pickChooser(second: Boolean): Boolean {
        val ns = nodes()
        val once = ns.firstOrNull {
            it.isEnabled && (it.txt().equals("Just once", true) || it.txt().equals("Once", true))
        }
        if (once != null) return clickNode(once)
        val r = Rect()
        val opts = ns.filter {
            val t = it.txt()
            it.isVisibleToUser &&
                (t.equals("X", true) || t.equals("Twitter", true) || t.startsWith("X ", true) || t.contains("Twitter", true))
        }.sortedWith(compareBy({ n -> n.getBoundsInScreen(r); r.left }, { n -> n.getBoundsInScreen(r); r.top }))
        if (opts.isEmpty()) return false
        return clickNode(if (second) opts.last() else opts.first())
    }
}
